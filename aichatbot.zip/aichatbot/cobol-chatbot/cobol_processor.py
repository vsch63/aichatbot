# File: cobol_processor.py
# Purpose: Handles reading and basic processing of COBOL files.

import os

COBOL_SOURCE_DIR = "cobol_source_code"
ALLOWED_EXTENSIONS = {'.cob', '.cbl', '.cpy','.COB','.CPY'} # Add more if needed

def get_cobol_files_content():
    """
    Reads all COBOL files from the COBOL_SOURCE_DIR.

    Returns:
        list: A list of dictionaries, where each dictionary contains
              'filename' and 'content' of a COBOL file.
              Returns an empty list if the directory doesn't exist or is empty.
    """
    cobol_data = []
    if not os.path.isdir(COBOL_SOURCE_DIR):
        print(f"Error: Directory '{COBOL_SOURCE_DIR}' not found.")
        return cobol_data

    for filename in os.listdir(COBOL_SOURCE_DIR):
        print("cobol directory:",COBOL_SOURCE_DIR)
        if os.path.splitext(filename)[1].lower() in ALLOWED_EXTENSIONS:
            filepath = os.path.join(COBOL_SOURCE_DIR, filename)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                cobol_data.append({"filename": filename, "content": content})
                print(f"Successfully read {filename}")
            except Exception as e:
                print(f"Error reading file {filename}: {e}")
    
    if not cobol_data:
        print(f"No COBOL files found in '{COBOL_SOURCE_DIR}' with allowed extensions.")
    return cobol_data

# --- File: llm_handler.py ---
# Purpose: Handles interaction with the LLM (Gemini API).

import google.generativeai as genai
import os

# Configure the Gemini API key
# IMPORTANT: Set the GOOGLE_API_KEY environment variable.
# For local testing, you could temporarily hardcode it, but this is NOT recommended.
# Example: os.environ['GOOGLE_API_KEY'] = "YOUR_API_KEY_HERE"
try:
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise ValueError("GOOGLE_API_KEY environment variable not set.")
    genai.configure(api_key=api_key)
except Exception as e:
    print(f"Error configuring Gemini API: {e}")
    # Fallback or further error handling can be added here

# Initialize the Generative Model
# Adjust model_name if needed, e.g., 'gemini-1.5-flash' or 'gemini-1.0-pro'
# 'gemini-1.5-flash' is good for speed and cost-effectiveness for many tasks.
MODEL_NAME = 'gemini-1.5-flash' 
try:
    model = genai.GenerativeModel(MODEL_NAME)
except Exception as e:
    print(f"Error initializing Gemini model: {e}")
    model = None # Ensure model is None if initialization fails

def get_answer_from_llm(question, cobol_programs_data):
    """
    Sends the question and COBOL code to the LLM and gets an answer.

    Args:
        question (str): The user's question.
        cobol_programs_data (list): List of dicts, each with 'filename' and 'content'.

    Returns:
        str: The LLM's answer, or an error message.
    """
    if not model:
        return "Error: Gemini model not initialized. Please check API key and configuration."
    if not cobol_programs_data:
        return "I don't have any COBOL programs to analyze. Please add your COBOL files to the 'cobol_source_code' directory."

    prompt_parts = [
        "You are an expert COBOL programmer and a helpful assistant designed to explain COBOL logic to users who are not familiar with COBOL.",
        "Analyze the following COBOL programs provided and answer the user's question.",
        "Explain the logic in simple, clear, non-technical language as much as possible.",
        "If the question is about a specific program or section, focus your answer on that.",
        "If the COBOL code is extensive, provide a concise summary relevant to the question.",
        "\nUser's Question: " + question + "\n",
        "--- COBOL PROGRAMS CONTEXT ---"
    ]

    for program in cobol_programs_data:
        prompt_parts.append(f"\n-- Start of COBOL Program: {program['filename']} --\n")
        prompt_parts.append(program['content'])
        prompt_parts.append(f"\n-- End of COBOL Program: {program['filename']} --\n")
    
    prompt_parts.append("--- END OF COBOL PROGRAMS CONTEXT ---")
    prompt_parts.append("\nBased on the provided COBOL code and the user's question, please provide your answer:")

    full_prompt = "\n".join(prompt_parts)

    # print("\n--- PROMPT SENT TO LLM ---") # For debugging
    # print(full_prompt[:2000] + "..." if len(full_prompt) > 2000 else full_prompt) # Print a snippet
    # print("--- END OF PROMPT SNIPPET ---\n")

    try:
        # Using generate_content for potentially complex inputs
        response = model.generate_content(full_prompt)
        
        # Check if the response has parts and text
        if response.parts:
            answer = "".join(part.text for part in response.parts)
        elif hasattr(response, 'text') and response.text: # Fallback for simpler response structure
             answer = response.text
        else: # Handle cases where response structure is unexpected or content is missing
            # Log the full response for debugging
            print(f"Debug: Unexpected LLM response structure: {response}")
            # Check for prompt feedback
            if response.prompt_feedback and response.prompt_feedback.block_reason:
                return f"Error: The request was blocked. Reason: {response.prompt_feedback.block_reason_message or response.prompt_feedback.block_reason}"
            return "Error: Received an empty or unexpected response from the AI. The COBOL code might be too extensive or the question too complex for the current model configuration. Try simplifying the question or reducing the number/size of COBOL files."
            
        return answer

    except Exception as e:
        print(f"Error calling Gemini API: {e}")
        # More specific error handling based on google.api_core.exceptions might be useful
        if "API key not valid" in str(e):
             return "Error: The Google API key is not valid. Please check your GOOGLE_API_KEY environment variable."
        if "429" in str(e) or "Resource has been exhausted" in str(e): # Quota exceeded
            return "Error: API quota exceeded. Please check your Google Cloud console for API limits or try again later."
        if "context length" in str(e).lower():
            return "Error: The provided COBOL code is too long for the model's context window. Please try with fewer or smaller COBOL files, or ask a more specific question that might allow the system to select relevant code."
        return f"An error occurred while communicating with the AI: {e}"

# --- File: app.py ---
# Purpose: Main Flask application.

from flask import Flask, request, render_template, jsonify
from cobol_processor import get_cobol_files_content
from llm_handler import get_answer_from_llm
import os

app = Flask(__name__)

# Check if COBOL source directory exists on startup
COBOL_SOURCE_DIR = r"C:\Users\vscha\OneDrive\Documents\aichatbot\cobol-chatbot\cobol_source_code"
if not os.path.exists(COBOL_SOURCE_DIR):
    print(f"Warning: The directory '{COBOL_SOURCE_DIR}' does not exist. Please create it and add your COBOL files.")
    # You could choose to create it:
    # os.makedirs(COBOL_SOURCE_DIR, exist_ok=True)
    # print(f"Created directory '{COBOL_SOURCE_DIR}'.")


@app.route('/')
def index():
    """Renders the main page."""
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask_question():
    """Handles the user's question, gets COBOL context, and queries the LLM."""
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    question = data.get('question')

    if not question:
        return jsonify({"error": "No question provided"}), 400

    print(f"Received question: {question}")

    # Step 1: Get COBOL files content
    cobol_programs = get_cobol_files_content()

    if not cobol_programs:
        # This message is now more informative based on cobol_processor.py
        if not os.path.isdir(COBOL_SOURCE_DIR):
             answer = f"Error: The COBOL source directory '{COBOL_SOURCE_DIR}' was not found. Please create it and add your COBOL files."
        else:
             answer = f"No COBOL files (.cob, .cbl, .cpy) found in the '{COBOL_SOURCE_DIR}' directory. Please add your COBOL programs there."
        return jsonify({"answer": answer})


    # Step 2: Get answer from LLM
    print("Sending data to LLM...")
    answer = get_answer_from_llm(question, cobol_programs)
    print("Received answer from LLM.")
    
    return jsonify({"answer": answer})

if __name__ == '__main__':
    # Ensure the cobol_source_code directory exists, create if not
    if not os.path.exists(COBOL_SOURCE_DIR):
        os.makedirs(COBOL_SOURCE_DIR)
        print(f"Created directory '{COBOL_SOURCE_DIR}'. Please add your COBOL files there.")
    app.run(debug=True) # debug=True is helpful for development
