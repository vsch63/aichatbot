# --- File: llm_handler.py ---
# Purpose: Handles interaction with the LLM (Gemini API).

import google.generativeai as genai
import os

# Configure the Gemini API key
# IMPORTANT: Set the GOOGLE_API_KEY environment variable.
# For local testing, you could temporarily hardcode it, but this is NOT recommended.
# Example: os.environ['GOOGLE_API_KEY'] = "YOUR_API_KEY_HERE"
os.environ['GOOGLE_API_KEY'] = "AIzaSyARcXhBjp6TW0Xr6t1v1fyYeoG2ZSYAhSw"
try:
    api_key = os.environ.get("GOOGLE_API_KEY")
    if api_key:
        print("api_key sucessfull")
    if not api_key:
        raise ValueError("GOOGLE_API_KEY environment variable not set.")
    genai.configure(api_key=api_key)
except Exception as e:
    print(f"Error configuring Gemini API: {e}")
    # Fallback or further error handling can be added here

# Initialize the Generative Model
# Adjust model_name if needed, e.g., 'gemini-1.5-flash' or 'gemini-1.0-pro'
# 'gemini-1.5-flash' is good for speed and cost-effectiveness for many tasks.
MODEL_NAME = 'gemini-1.5-flash' 
try:
    model = genai.GenerativeModel(MODEL_NAME)
except Exception as e:
    print(f"Error initializing Gemini model: {e}")
    model = None # Ensure model is None if initialization fails

def get_answer_from_llm(question, cobol_programs_data):
    """
    Sends the question and COBOL code to the LLM and gets an answer.

    Args:
        question (str): The user's question.
        cobol_programs_data (list): List of dicts, each with 'filename' and 'content'.

    Returns:
        str: The LLM's answer, or an error message.
    """
    if not model:
        return "Error: Gemini model not initialized. Please check API key and configuration."
    if not cobol_programs_data:
        return "I don't have any COBOL programs to analyze. Please add your COBOL files to the 'cobol_source_code' directory."

    prompt_parts = [
        "You are an expert COBOL programmer and a helpful assistant designed to explain COBOL logic to users who are not familiar with COBOL.",
        "Analyze the following COBOL programs provided and answer the user's question.",
        "Explain the logic in simple, clear, non-technical language as much as possible.",
        "If the question is about a specific program or section, focus your answer on that.",
        "If the COBOL code is extensive, provide a concise summary relevant to the question.",
        "\nUser's Question: " + question + "\n",
        "--- COBOL PROGRAMS CONTEXT ---"
    ]

    for program in cobol_programs_data:
        prompt_parts.append(f"\n-- Start of COBOL Program: {program['filename']} --\n")
        prompt_parts.append(program['content'])
        prompt_parts.append(f"\n-- End of COBOL Program: {program['filename']} --\n")
    
    prompt_parts.append("--- END OF COBOL PROGRAMS CONTEXT ---")
    prompt_parts.append("\nBased on the provided COBOL code and the user's question, please provide your answer:")

    full_prompt = "\n".join(prompt_parts)

    # print("\n--- PROMPT SENT TO LLM ---") # For debugging
    # print(full_prompt[:2000] + "..." if len(full_prompt) > 2000 else full_prompt) # Print a snippet
    # print("--- END OF PROMPT SNIPPET ---\n")

    try:
        # Using generate_content for potentially complex inputs
        response = model.generate_content(full_prompt)
        
        # Check if the response has parts and text
        if response.parts:
            answer = "".join(part.text for part in response.parts)
        elif hasattr(response, 'text') and response.text: # Fallback for simpler response structure
             answer = response.text
        else: # Handle cases where response structure is unexpected or content is missing
            # Log the full response for debugging
            print(f"Debug: Unexpected LLM response structure: {response}")
            # Check for prompt feedback
            if response.prompt_feedback and response.prompt_feedback.block_reason:
                return f"Error: The request was blocked. Reason: {response.prompt_feedback.block_reason_message or response.prompt_feedback.block_reason}"
            return "Error: Received an empty or unexpected response from the AI. The COBOL code might be too extensive or the question too complex for the current model configuration. Try simplifying the question or reducing the number/size of COBOL files."
            
        return answer

    except Exception as e:
        print(f"Error calling Gemini API: {e}")
        # More specific error handling based on google.api_core.exceptions might be useful
        if "API key not valid" in str(e):
             return "Error: The Google API key is not valid. Please check your GOOGLE_API_KEY environment variable."
        if "429" in str(e) or "Resource has been exhausted" in str(e): # Quota exceeded
            return "Error: API quota exceeded. Please check your Google Cloud console for API limits or try again later."
        if "context length" in str(e).lower():
            return "Error: The provided COBOL code is too long for the model's context window. Please try with fewer or smaller COBOL files, or ask a more specific question that might allow the system to select relevant code."
        return f"An error occurred while communicating with the AI: {e}"

