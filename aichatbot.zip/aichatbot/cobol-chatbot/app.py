# --- File: app.py ---
# Purpose: Main Flask application.

from flask import Flask, request, render_template, jsonify
from cobol_processor import get_cobol_files_content
from llm_handler import get_answer_from_llm
import os

app = Flask(__name__)

# Check if COBOL source directory exists on startup
COBOL_SOURCE_DIR = r"C:\Users\vscha\OneDrive\Documents\aichatbot\cobol-chatbot\cobol_source_code"
if not os.path.exists(COBOL_SOURCE_DIR):
    print(f"Warning: The directory '{COBOL_SOURCE_DIR}' does not exist. Please create it and add your COBOL files.")
    # You could choose to create it:
    # os.makedirs(COBOL_SOURCE_DIR, exist_ok=True)
    # print(f"Created directory '{COBOL_SOURCE_DIR}'.")


@app.route('/')
def index():
    """Renders the main page."""
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask_question():
    """Handles the user's question, gets COBOL context, and queries the LLM."""
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    question = data.get('question')

    if not question:
        return jsonify({"error": "No question provided"}), 400

    print(f"Received question: {question}")

    # Step 1: Get COBOL files content
    cobol_programs = get_cobol_files_content()

    if not cobol_programs:
        # This message is now more informative based on cobol_processor.py
        if not os.path.isdir(COBOL_SOURCE_DIR):
             answer = f"Error: The COBOL source directory '{COBOL_SOURCE_DIR}' was not found. Please create it and add your COBOL files."
        else:
             answer = f"No COBOL files (.cob, .cbl, .cpy) found in the '{COBOL_SOURCE_DIR}' directory. Please add your COBOL programs there."
        return jsonify({"answer": answer})


    # Step 2: Get answer from LLM
    print("Sending data to LLM...")
    answer = get_answer_from_llm(question, cobol_programs)
    print("Received answer from LLM.")
    
    return jsonify({"answer": answer})

if __name__ == '__main__':
    # Ensure the cobol_source_code directory exists, create if not
    if not os.path.exists(COBOL_SOURCE_DIR):
        os.makedirs(COBOL_SOURCE_DIR)
        print(f"Created directory '{COBOL_SOURCE_DIR}'. Please add your COBOL files there.")
    app.run(debug=True) # debug=True is helpful for development
